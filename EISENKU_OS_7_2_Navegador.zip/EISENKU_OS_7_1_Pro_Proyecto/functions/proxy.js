// Proxy de compatibilidad para el Navegador EISEN (Cloudflare Pages Functions).
// Quita X-Frame-Options / CSP para que las páginas se puedan ver dentro de una pestaña del navegador.
// Se publica solo en /proxy cuando subes TODA la carpeta (incluida "functions") a Cloudflare Pages.
const BLOCKED = /^(localhost|.*\.local|.*\.internal|0\.0\.0\.0|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|\[?::1\]?$)/i;
const DROP = ['x-frame-options','content-security-policy','content-security-policy-report-only','set-cookie','content-encoding','content-length','strict-transport-security','cross-origin-opener-policy','cross-origin-embedder-policy','cross-origin-resource-policy'];

const inject = base => `<base href="${base.replace(/"/g, '&quot;')}"><script>(function(){var P=parent;function s(m){m.eisen=1;P.postMessage(m,'*')}
var PX=location.href.split('?')[0]+'?url=';
document.addEventListener('click',function(e){var a=e.target&&e.target.closest&&e.target.closest('a[href]');if(!a||e.defaultPrevented||e.button>0)return;var h=a.getAttribute('href')||'';if(/^(javascript:|mailto:|tel:|#)/i.test(h))return;e.preventDefault();s({nav:a.href,tab:(e.ctrlKey||e.metaKey||a.target==='_blank')?1:0})},true);
document.addEventListener('submit',function(e){var f=e.target;if(e.defaultPrevented)return;var act=new URL(f.getAttribute('action')||'',document.baseURI);if((f.method||'get').toLowerCase()==='get'){e.preventDefault();var u=new URL(act.href);u.search='';new FormData(f).forEach(function(v,k){if(typeof v==='string')u.searchParams.append(k,v)});s({nav:u.href})}else{f.action=PX+encodeURIComponent(act.href)}},true);
window.open=function(u){if(u)s({nav:new URL(u,document.baseURI).href,tab:1});return null};
addEventListener('load',function(){s({loaded:1,title:document.title,url:${JSON.stringify(base)}})});
})()</script>`;

export async function onRequest({ request }) {
  const u = new URL(request.url);
  const json = (o, st = 200) => new Response(JSON.stringify(o), { status: st, headers: { 'content-type': 'application/json' } });
  if (u.searchParams.has('ping')) return json({ ok: true });

  // Solo se puede usar desde el propio escritorio (dentro de un iframe) o escribiendo la URL directamente.
  const site = request.headers.get('Sec-Fetch-Site'), dest = request.headers.get('Sec-Fetch-Dest');
  if (site && site !== 'same-origin' && site !== 'none' && dest !== 'iframe') return json({ error: 'Uso no permitido' }, 403);

  let t;
  try { t = new URL(u.searchParams.get('url') || ''); } catch { return json({ error: 'URL inválida' }, 400); }
  if (!/^https?:$/.test(t.protocol) || BLOCKED.test(t.hostname)) return json({ error: 'Destino no permitido' }, 400);

  const h = new Headers();
  for (const k of ['user-agent', 'accept', 'accept-language', 'content-type']) { const v = request.headers.get(k); if (v) h.set(k, v); }
  const body = ['GET', 'HEAD'].includes(request.method) ? undefined : request.body;
  let res;
  try { res = await fetch(t.href, { method: request.method, headers: h, body, redirect: 'follow' }); }
  catch (e) { return json({ error: 'No se pudo conectar con el sitio' }, 502); }

  const out = new Headers(res.headers);
  DROP.forEach(k => out.delete(k));
  out.set('x-robots-tag', 'noindex');
  const resp = new Response(res.body, { status: res.status, headers: out });

  if (/text\/html/i.test(out.get('content-type') || '')) {
    let done = false;
    const put = { element(e) { if (!done) { done = true; e.prepend(inject(res.url || t.href), { html: true }); } } };
    return new HTMLRewriter()
      .on('html', put).on('head', put)
      .on('meta[http-equiv]', { element(e) { if (/content-security-policy/i.test(e.getAttribute('http-equiv') || '')) e.remove(); } })
      .transform(resp);
  }
  return resp;
}
