(() => {
  'use strict';

  /* --------------------------------------------------------------------------
     A. UTILIDADES Y ESTADO PERSISTENTE
     -------------------------------------------------------------------------- */
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const storage = {
    get: (k, def) => { try { return JSON.parse(localStorage.getItem('eisen_' + k)) ?? def; } catch { return def; } },
    set: (k, val) => { try { localStorage.setItem('eisen_' + k, JSON.stringify(val)); return true; } catch { return false; } }
  };

  let zIndexCounter = 100;
  let activeWindow = null;

  /* --------------------------------------------------------------------------
     B. GESTIÓN DE VENTANAS (VENTANAS MIN/MAX/MOVE)
     -------------------------------------------------------------------------- */
  function openWindow(winId) {
    const win = $('#win-' + winId);
    if (!win) return;
    win.classList.remove('minimized');
    win.classList.add('open');
    focusWindow(win);
    updateTaskbarButtons();
    // Acciones automáticas por app al abrir
    if (winId === 'excel') renderExcelTable();
    if (winId === 'arcade') initShooterGame();
    if (winId === 'explorer') renderExplorer();
    if (winId === 'browser') ebInit();
  }

  function focusWindow(win) {
    $$('.window').forEach(w => w.classList.remove('active'));
    win.classList.add('active');
    win.style.zIndex = ++zIndexCounter;
    activeWindow = win;
  }

  function setupWindowInteractions() {
    $$('.window').forEach(win => {
      win.addEventListener('pointerdown', () => focusWindow(win));
      const header = win.querySelector('.window-header');
      if (!header) return;

      // Arrastrar ventana
      let drag = null;
      header.addEventListener('pointerdown', e => {
        if (e.target.closest('button') || win.classList.contains('maximized')) return;
        const rect = win.getBoundingClientRect();
        drag = { x: e.clientX - rect.left, y: e.clientY - rect.top };
        header.setPointerCapture(e.pointerId);
        focusWindow(win);
      });
      header.addEventListener('pointermove', e => {
        if (!drag) return;
        const newX = Math.max(0, Math.min(window.innerWidth - win.offsetWidth, e.clientX - drag.x));
        const newY = Math.max(0, Math.min(window.innerHeight - 50, e.clientY - drag.y));
        win.style.left = newX + 'px';
        win.style.top = newY + 'px';
      });
      const stopDrag = () => drag = null;
      header.addEventListener('pointerup', stopDrag);
      header.addEventListener('pointercancel', stopDrag);

      // Doble click maximizar
      header.addEventListener('dblclick', e => {
        if (e.target.closest('button')) return;
        win.classList.toggle('maximized');
      });

      // Botones ventana
      win.querySelectorAll('.win-ctrl-btn').forEach(btn => {
        btn.onclick = () => {
          const act = btn.dataset.act;
          if (act === 'close') win.classList.remove('open', 'maximized', 'minimized');
          if (act === 'min') win.classList.add('minimized');
          if (act === 'max') { win.classList.toggle('maximized'); win.classList.remove('minimized'); }
          updateTaskbarButtons();
        };
      });
    });
  }

  function updateTaskbarButtons() {
    $$('#taskbar-center [data-launch]').forEach(tbBtn => {
      const app = tbBtn.dataset.launch;
      const win = $('#win-' + app);
      if (win && win.classList.contains('open')) {
        tbBtn.classList.add('running');
        tbBtn.classList.toggle('active', win.classList.contains('active') && !win.classList.contains('minimized'));
      } else {
        tbBtn.classList.remove('running', 'active');
      }
    });
  }

  /* --------------------------------------------------------------------------
     NAVEGADOR EISEN: pestañas internas, 3 navegadores, buscador y proxy opcional
     -------------------------------------------------------------------------- */
  const EB_BROWSERS = {
    web:  { name: 'Eisen Web',     icon: '🌐', color: '#0078d4', engine: 'Google',     search: 'https://www.google.com/search?q=%s&igu=1', desc: 'Navegador general con buscador Google.' },
    priv: { name: 'Eisen Privado', icon: '🕶️', color: '#8b5cf6', engine: 'DuckDuckGo', search: 'https://html.duckduckgo.com/html/?q=%s',  desc: 'Búsquedas con DuckDuckGo, sin rastreo.' },
    nova: { name: 'Eisen Nova',    icon: '🧭', color: '#10b981', engine: 'Bing',       search: 'https://www.bing.com/search?q=%s',        desc: 'Búsquedas con Bing.' }
  };
  const EB_ALLOW = 'fullscreen; autoplay; camera; microphone; geolocation; clipboard-read; clipboard-write; encrypted-media; picture-in-picture; display-capture; web-share; accelerometer; gyroscope; payment; midi';
  const EB_SANDBOX = 'allow-scripts allow-forms allow-popups allow-modals allow-downloads allow-presentation allow-pointer-lock allow-popups-to-escape-sandbox';
  const eb = { cur: 'web', sessions: {}, ready: false, proxyDetected: false, uid: 0 };
  const ebEsc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ebS = () => eb.sessions[eb.cur];
  const ebCur = () => ebS().tabs.find(t => t.id === ebS().active);
  const ebHost = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return u; } };
  const ebTitle = t => t.title || (t.url === 'about:newtab' ? 'Nueva pestaña' : t.url === 'about:html' ? 'Documento' : ebHost(t.url));
  const ebProxyMode = () => storage.get('browser_proxy_mode', 'auto');
  const ebCustomProxy = () => String(storage.get('browser_proxy_url', '') || '').trim();
  const ebPrefix = () => ebCustomProxy() || '/proxy?url=';
  const ebSameOriginProxy = () => { try { return new URL(ebPrefix(), location.href).origin === location.origin; } catch { return false; } };

  function ebMakeTab(url) {
    return { id: 't' + (++eb.uid), url, title: '', hist: [url], hi: 0, loading: false, loaded: false, frame: null, htmlSrc: '', forceProxy: false, noteOff: false };
  }
  function ebUseProxy(t) {
    if (!/^https?:/i.test(t.url)) return false;
    if (t.forceProxy) return true;
    const m = ebProxyMode();
    if (m === 'off') return false;
    if (m === 'on') return true;
    return eb.proxyDetected || !!ebCustomProxy();
  }

  function ebResolve(raw) {
    const v = String(raw || '').trim();
    if (!v) return '';
    if (/^about:(newtab|blank)$/i.test(v)) return 'about:newtab';
    if (/^(https?|file|blob|data):/i.test(v)) return v;
    if (/^(localhost|(\d{1,3}\.){3}\d{1,3})(:\d+)?([/?#]|$)/i.test(v)) return 'http://' + v;
    if (!/\s/.test(v) && /^([\w-]+\.)+[a-z]{2,}(:\d+)?([/?#].*)?$/i.test(v)) return 'https://' + v;
    return EB_BROWSERS[eb.cur].search.replace('%s', encodeURIComponent(v));
  }

  function ebNewTabHtml() {
    const b = EB_BROWSERS[eb.cur], light = document.documentElement.dataset.theme === 'light';
    const bg = light ? '#f4f6fb' : '#161a24', fg = light ? '#191c24' : '#f5f6fa', mut = light ? '#5e6678' : '#9aa1b2', card = light ? '#ffffff' : '#222838';
    const links = [['Wikipedia', 'https://es.wikipedia.org', '📚'], ['YouTube', 'https://www.youtube.com', '▶️'], ['GitHub', 'https://github.com', '🐙'], ['Mapas', 'https://www.openstreetmap.org', '🗺️'], ['Noticias', 'https://news.google.com', '📰'], ['Traductor', 'https://translate.google.com', '🔤']];
    return `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:${bg};color:${fg};font-family:system-ui,Segoe UI,sans-serif}
.w{width:min(640px,92vw);text-align:center}.logo{font-size:54px}h1{margin:6px 0 20px;font-size:26px}
form{display:flex;gap:8px}input{flex:1;padding:13px 18px;border-radius:99px;border:2px solid ${b.color}55;background:${card};color:${fg};font-size:15px;outline:none}input:focus{border-color:${b.color}}
button{padding:0 22px;border:0;border-radius:99px;background:${b.color};color:#fff;font-weight:700;cursor:pointer}
.l{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:26px}.l a{display:block;padding:14px 8px;border-radius:14px;background:${card};color:${fg};text-decoration:none;font-size:13px}.l a:hover{outline:2px solid ${b.color}}.l span{display:block;font-size:22px;margin-bottom:4px}
p{color:${mut};font-size:12px;margin-top:18px}</style>
<div class="w"><div class="logo">${b.icon}</div><h1>${b.name}</h1>
<form id="f"><input id="q" autofocus autocomplete="off" placeholder="Busca en ${b.engine} o escribe una dirección"><button>Buscar</button></form>
<div class="l">${links.map(l => `<a href="#" data-u="${l[1]}"><span>${l[2]}</span>${l[0]}</a>`).join('')}</div>
<p>Buscador: ${b.engine}</p></div>
<script>var q=document.getElementById('q');document.getElementById('f').onsubmit=function(e){e.preventDefault();var v=q.value.trim();if(v)parent.postMessage({eisen:1,nav:v},'*')};
document.querySelectorAll('a[data-u]').forEach(function(a){a.onclick=function(e){e.preventDefault();parent.postMessage({eisen:1,nav:a.dataset.u},'*')}});<\/script>`;
  }

  function ebEnsureFrame(t) {
    if (t.frame) return;
    const f = document.createElement('iframe');
    f.className = 'eb-frame';
    f.setAttribute('allow', EB_ALLOW);
    f.setAttribute('allowfullscreen', '');
    f.addEventListener('load', () => {
      if (!f.getAttribute('src') && !f.hasAttribute('srcdoc')) return;
      t.loading = false;
      try { const d = f.contentDocument; if (d && d.title && /^https?:/i.test(t.url) && !ebUseProxy(t)) t.title = d.title; } catch { /* sitio de otro origen */ }
      ebRenderTabs(); ebRenderBar();
    });
    $('#eb-views').appendChild(f);
    t.frame = f;
  }

  function ebLoad(t) {
    ebEnsureFrame(t);
    const f = t.frame;
    t.loaded = true;
    if (t.url === 'about:newtab' || t.url === 'about:html') {
      f.removeAttribute('sandbox'); f.removeAttribute('src');
      f.srcdoc = t.url === 'about:html' ? t.htmlSrc : ebNewTabHtml();
      t.loading = false;
      return;
    }
    f.removeAttribute('srcdoc');
    const proxied = ebUseProxy(t);
    if (proxied && ebSameOriginProxy()) f.setAttribute('sandbox', EB_SANDBOX); else f.removeAttribute('sandbox');
    t.loading = true;
    f.src = proxied ? ebPrefix() + encodeURIComponent(t.url) : t.url;
  }

  function ebNavigate(t, url, push = true) {
    t.url = url; t.title = ''; t.noteOff = false;
    if (push) { t.hist = t.hist.slice(0, t.hi + 1); t.hist.push(url); t.hi = t.hist.length - 1; }
    ebLoad(t); ebRender(); ebSave();
  }
  function ebGo(delta) {
    const t = ebCur(), i = t.hi + delta;
    if (i < 0 || i >= t.hist.length) return;
    t.hi = i; t.url = t.hist[i]; t.title = '';
    ebLoad(t); ebRender();
  }
  function ebAddTab(sess = eb.cur, url = 'about:newtab') {
    const t = ebMakeTab(url);
    eb.sessions[sess].tabs.push(t);
    return t;
  }
  function ebActivate(t) {
    const s = ebS();
    s.active = t.id;
    if (!t.loaded) ebLoad(t);
    ebRender(); ebSave();
  }
  function ebClose(id) {
    const s = ebS(), i = s.tabs.findIndex(t => t.id === id);
    if (i < 0) return;
    const [t] = s.tabs.splice(i, 1);
    if (t.frame) t.frame.remove();
    if (!s.tabs.length) { const n = ebAddTab(); s.active = n.id; ebLoad(n); }
    else if (s.active === id) { const n = s.tabs[Math.min(i, s.tabs.length - 1)]; s.active = n.id; if (!n.loaded) ebLoad(n); }
    ebRender(); ebSave();
  }

  function ebSave() {
    const out = {};
    Object.entries(eb.sessions).forEach(([id, s]) => {
      const keep = s.tabs.filter(t => /^https?:/i.test(t.url));
      const a = s.tabs.find(t => t.id === s.active);
      out[id] = { urls: keep.map(t => t.url), active: Math.max(0, keep.indexOf(a)) };
    });
    storage.set('browser_tabs', out);
  }

  function ebRenderTabs() {
    const s = ebS();
    $('#eb-tabs').innerHTML = s.tabs.map(t => `<div class="eb-tab${t.id === s.active ? ' active' : ''}" data-tab="${t.id}" title="${ebEsc(ebTitle(t))}"><span>${t.loading ? '⏳' : t.url === 'about:newtab' ? '🏠' : t.url === 'about:html' ? '📄' : '🌐'}</span><span class="eb-tab-title">${ebEsc(ebTitle(t))}</span><button class="eb-tab-x" data-close="${t.id}" aria-label="Cerrar pestaña">✕</button></div>`).join('') + '<button class="eb-newtab" id="eb-new" title="Nueva pestaña" aria-label="Nueva pestaña">＋</button>';
  }
  function ebRenderBar() {
    const t = ebCur(); if (!t) return;
    const omni = $('#nav-url-input');
    if (document.activeElement !== omni) omni.value = /^about:/.test(t.url) ? (t.url === 'about:html' ? ebTitle(t) : '') : t.url;
    $('#nav-btn-back').disabled = t.hi <= 0;
    $('#nav-btn-fwd').disabled = t.hi >= t.hist.length - 1;
    $('#nav-btn-reload').textContent = t.loading ? '✕' : '↻';
    $('#nav-btn-ext').disabled = !/^https?:/i.test(t.url);
    $('#eb-loadbar').classList.toggle('on', !!t.loading);
    const note = $('#eb-note');
    if (/^https?:/i.test(t.url) && !ebUseProxy(t) && !t.noteOff) {
      note.hidden = false;
      note.innerHTML = '<span>Si la página sale en blanco o con error, ese sitio no permite mostrarse dentro de otra página.</span><button data-n="proxy">Cargar con proxy</button><button data-n="ext">Abrir en pestaña real ↗</button><button data-n="x" aria-label="Cerrar aviso">✕</button>';
    } else note.hidden = true;
  }
  function ebShowFrames() {
    Object.entries(eb.sessions).forEach(([id, s]) => s.tabs.forEach(t => { if (t.frame) t.frame.classList.toggle('show', id === eb.cur && t.id === s.active); }));
  }
  function ebRender() {
    const b = EB_BROWSERS[eb.cur];
    $('#win-browser').style.setProperty('--eb-accent', b.color);
    $('#eb-title').textContent = `${b.icon} ${b.name} · ${b.engine}`;
    $('#eb-switch').value = eb.cur;
    ebRenderTabs(); ebRenderBar(); ebShowFrames();
  }

  function ebSwitch(id) {
    if (!EB_BROWSERS[id]) return;
    eb.cur = id; storage.set('browser_default', id);
    $('#cfg-browser').value = id;
    const t = ebCur(); if (!t.loaded) ebLoad(t);
    ebRender();
    const d = $('#cfg-browser-desc'); if (d) d.textContent = EB_BROWSERS[id].desc;
  }

  function ebInit() {
    if (eb.ready) return;
    eb.ready = true;
    const def = storage.get('browser_default', 'web');
    eb.cur = EB_BROWSERS[def] ? def : 'web';
    const saved = storage.get('browser_tabs', {});
    Object.keys(EB_BROWSERS).forEach(id => {
      const s = { tabs: [], active: null };
      ((saved[id] && saved[id].urls) || []).forEach(u => { if (typeof u === 'string' && /^https?:/i.test(u)) s.tabs.push(ebMakeTab(u)); });
      if (!s.tabs.length) s.tabs.push(ebMakeTab('about:newtab'));
      s.active = s.tabs[Math.min((saved[id] && saved[id].active) || 0, s.tabs.length - 1)].id;
      eb.sessions[id] = s;
    });
    const t = ebCur(); ebLoad(t);
    ebRender();
    fetch('/proxy?ping=1').then(r => r.ok ? r.json() : null).then(j => {
      if (j && j.ok) { eb.proxyDetected = true; ebRenderBar(); }
    }).catch(() => {});
  }

  // API pública del navegador
  function ebOpenUrl(raw, newTab = false) {
    const url = ebResolve(raw);
    if (!url) return;
    openWindow('browser');
    ebInit();
    let t = ebCur();
    if (newTab) {
      const same = ebS().tabs.find(x => x.url === url);
      if (same) { ebActivate(same); return; }
      if (t.url === 'about:newtab') { /* reutiliza la pestaña vacía */ } else { t = ebAddTab(); ebS().active = t.id; }
    }
    ebS().active = t.id;
    ebNavigate(t, url);
  }
  function ebOpenHtml(title, html) {
    openWindow('browser'); ebInit();
    const t = ebAddTab(eb.cur, 'about:html');
    t.htmlSrc = html; t.title = title; t.hist = ['about:html'];
    ebS().active = t.id;
    ebLoad(t); ebRender();
  }

  function navigateInApp(rawUrl) {
    ebOpenUrl(rawUrl, true);
    closeFlyouts();
  }

  // Eventos del navegador
  (function ebWire() {
    $('#eb-tabs').addEventListener('click', e => {
      const x = e.target.closest('[data-close]');
      if (x) { ebClose(x.dataset.close); return; }
      if (e.target.closest('#eb-new')) { const t = ebAddTab(); ebActivate(t); $('#nav-url-input').focus(); return; }
      const tab = e.target.closest('[data-tab]');
      if (tab) { const t = ebS().tabs.find(z => z.id === tab.dataset.tab); if (t) ebActivate(t); }
    });
    $('#eb-tabs').addEventListener('auxclick', e => { const tab = e.target.closest('[data-tab]'); if (tab && e.button === 1) { e.preventDefault(); ebClose(tab.dataset.tab); } });
    const go = () => { const v = $('#nav-url-input').value; const url = ebResolve(v); if (!url) return; ebNavigate(ebCur(), url); $('#nav-url-input').blur(); };
    $('#nav-btn-go').onclick = go;
    $('#nav-url-input').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); go(); } });
    $('#nav-url-input').addEventListener('focus', e => e.target.select());
    $('#nav-url-input').addEventListener('blur', ebRenderBar);
    $('#nav-btn-back').onclick = () => ebGo(-1);
    $('#nav-btn-fwd').onclick = () => ebGo(1);
    $('#nav-btn-home').onclick = () => ebNavigate(ebCur(), 'about:newtab');
    $('#nav-btn-reload').onclick = () => {
      const t = ebCur();
      if (t.loading) { try { t.frame.contentWindow.stop(); } catch { /* ignorar */ } t.loading = false; ebRender(); } else ebLoad(t), ebRender();
    };
    $('#nav-btn-ext').onclick = () => { const t = ebCur(); if (/^https?:/i.test(t.url)) window.open(t.url, '_blank', 'noopener'); };
    $('#eb-switch').innerHTML = Object.entries(EB_BROWSERS).map(([id, b]) => `<option value="${id}">${b.icon} ${b.name}</option>`).join('');
    $('#eb-switch').onchange = e => ebSwitch(e.target.value);
    $('#eb-note').addEventListener('click', e => {
      const b = e.target.closest('[data-n]'); if (!b) return;
      const t = ebCur();
      if (b.dataset.n === 'proxy') { t.forceProxy = true; ebLoad(t); ebRender(); }
      if (b.dataset.n === 'ext') window.open(t.url, '_blank', 'noopener');
      if (b.dataset.n === 'x') { t.noteOff = true; ebRenderBar(); }
    });
    // Mensajes desde páginas internas (inicio) y desde páginas cargadas con proxy
    window.addEventListener('message', e => {
      const m = e.data;
      if (!m || typeof m !== 'object' || !m.eisen || !eb.ready) return;
      let tab = null, sess = null;
      Object.entries(eb.sessions).forEach(([id, s]) => s.tabs.forEach(t => { if (t.frame && t.frame.contentWindow === e.source) { tab = t; sess = id; } }));
      if (!tab) return;
      if (m.nav) {
        const url = ebResolve(String(m.nav)); if (!url) return;
        if (m.tab) { const n = ebAddTab(sess); if (sess === eb.cur) { ebS().active = n.id; } ebNavigate(n, url); }
        else ebNavigate(tab, url);
      } else if (m.loaded) {
        tab.loading = false;
        if (m.title) tab.title = String(m.title).slice(0, 120);
        if (typeof m.url === 'string' && /^https?:/i.test(m.url) && m.url !== tab.url) { tab.url = m.url; tab.hist[tab.hi] = m.url; ebSave(); }
        ebRenderTabs(); ebRenderBar();
      }
    });
    // Atajos con la ventana del navegador activa
    document.addEventListener('keydown', e => {
      if (!eb.ready || !activeWindow || activeWindow.id !== 'win-browser' || !activeWindow.classList.contains('open')) return;
      const k = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && k === 'l') { e.preventDefault(); $('#nav-url-input').focus(); }
      if (e.altKey && e.key === 'ArrowLeft') { e.preventDefault(); ebGo(-1); }
      if (e.altKey && e.key === 'ArrowRight') { e.preventDefault(); ebGo(1); }
    });
    // Configuración del navegador
    $('#cfg-browser').innerHTML = Object.entries(EB_BROWSERS).map(([id, b]) => `<option value="${id}">${b.icon} ${b.name} (${b.engine})</option>`).join('');
    const sel = storage.get('browser_default', 'web'); eb.cur = EB_BROWSERS[sel] ? sel : 'web';
    $('#cfg-browser').value = eb.cur;
    $('#cfg-browser-desc').textContent = EB_BROWSERS[eb.cur].desc;
    $('#cfg-browser').onchange = e => { storage.set('browser_default', e.target.value); if (eb.ready) ebSwitch(e.target.value); else { eb.cur = e.target.value; $('#cfg-browser-desc').textContent = EB_BROWSERS[eb.cur].desc; } };
    $('#cfg-proxy-mode').value = ebProxyMode();
    $('#cfg-proxy-mode').onchange = e => { storage.set('browser_proxy_mode', e.target.value); if (eb.ready) ebRenderBar(); };
    $('#cfg-proxy-url').value = ebCustomProxy();
    $('#cfg-proxy-url').onchange = e => { storage.set('browser_proxy_url', e.target.value.trim()); if (eb.ready) ebRenderBar(); };
  })();

  document.addEventListener('click', e => {
    const external = e.target.closest('[data-external-url]');
    if (external) { e.preventDefault(); navigateInApp(external.dataset.externalUrl); }
  });

  // Enlazado de lanzadores globales
  document.addEventListener('click', e => {
    const launcher = e.target.closest('[data-launch]');
    if (launcher) {
      const app = launcher.dataset.launch;
      const win = $('#win-' + app);
      if (win && win.classList.contains('open') && !win.classList.contains('minimized') && win.classList.contains('active')) {
        win.classList.add('minimized');
      } else {
        openWindow(app);
      }
      closeFlyouts();
    }
  });

  /* --------------------------------------------------------------------------
     C. MENÚ INICIO & ACTION CENTER
     -------------------------------------------------------------------------- */
  const startMenu = $('#start-menu-panel');
  const actionCenter = $('#action-center');

  function closeFlyouts() {
    startMenu.classList.remove('open');
    actionCenter.classList.remove('open');
    $('#context-menu').style.display = 'none';
  }

  $('#tb-start-trigger').onclick = e => {
    e.stopPropagation();
    actionCenter.classList.remove('open');
    startMenu.classList.toggle('open');
  };

  $('#systray-quick-btn').onclick = e => {
    e.stopPropagation();
    startMenu.classList.remove('open');
    actionCenter.classList.toggle('open');
  };

  document.addEventListener('pointerdown', e => {
    if (!e.target.closest('#start-menu-panel') && !e.target.closest('#tb-start-trigger') &&
        !e.target.closest('#action-center') && !e.target.closest('#systray-quick-btn') &&
        !e.target.closest('#context-menu')) {
      closeFlyouts();
    }
  });

  // Brillo
  $('#qc-brightness').oninput = e => {
    $('#screen-brightness-overlay').style.opacity = e.target.value;
  };

  // Menú contextual en el escritorio
  $('#desktop-viewport').addEventListener('contextmenu', e => {
    if (e.target.closest('.window')) return;
    e.preventDefault();
    closeFlyouts();
    const cm = $('#context-menu');
    cm.style.display = 'block';
    cm.style.left = Math.min(window.innerWidth - 200, e.clientX) + 'px';
    cm.style.top = Math.min(window.innerHeight - 200, e.clientY) + 'px';
  });

  $('#ctx-new-doc').onclick = () => { openWindow('word'); closeFlyouts(); };
  $('#ctx-new-sheet').onclick = () => { openWindow('excel'); closeFlyouts(); };
  $('#ctx-new-folder').onclick = () => { openWindow('explorer'); closeFlyouts(); };

  /* --------------------------------------------------------------------------
     D. CATÁLOGO PRO (> 200 APLICACIONES)
     -------------------------------------------------------------------------- */
  const catalogList = [
    // Productividad & Oficina
    { id: 'word', name: 'EISEN Writer', cat: 'Productividad', icon: '📝', desc: 'Editor enriquecido con exportación a PDF.' },
    { id: 'excel', name: 'EISEN Sheets', cat: 'Productividad', icon: '📊', desc: 'Hojas de cálculo con fórmulas y gráficos.' },
    { id: 'pdf', name: 'PDF Studio', cat: 'Productividad', icon: '📕', desc: 'Visor y maquetador de archivos PDF.' },
    { id: 'notion', name: 'Notion Workspace', cat: 'Productividad', icon: '📓', ext: 'https://www.notion.so' },
    { id: 'trello', name: 'Trello Kanban', cat: 'Productividad', icon: '📋', ext: 'https://trello.com' },
    { id: 'slack', name: 'Slack Web', cat: 'Productividad', icon: '💬', ext: 'https://slack.com' },
    { id: 'asana', name: 'Asana Projects', cat: 'Productividad', icon: '🎯', ext: 'https://app.asana.com' },
    { id: 'todoist', name: 'Todoist', cat: 'Productividad', icon: '✅', ext: 'https://todoist.com' },
    { id: 'evernote', name: 'Evernote Web', cat: 'Productividad', icon: '🐘', ext: 'https://www.evernote.com' },
    { id: 'obsidian', name: 'Obsidian Hub', cat: 'Productividad', icon: '💎', ext: 'https://obsidian.md' },
    { id: 'miro', name: 'Miro Pizarras', cat: 'Productividad', icon: '🟡', ext: 'https://miro.com' },
    { id: 'airtable', name: 'Airtable Base', cat: 'Productividad', icon: '🗃️', ext: 'https://airtable.com' },
    { id: 'coda', name: 'Coda Docs', cat: 'Productividad', icon: '📜', ext: 'https://coda.io' },

    // Desarrollo y Programación
    { id: 'terminal', name: 'Terminal Bash', cat: 'Desarrollo', icon: '$_', desc: 'Consola de comandos simulada.' },
    { id: 'vscode', name: 'VS Code for Web', cat: 'Desarrollo', icon: '💻', ext: 'https://vscode.dev' },
    { id: 'github', name: 'GitHub Code', cat: 'Desarrollo', icon: '🐙', ext: 'https://github.com' },
    { id: 'codepen', name: 'CodePen Editor', cat: 'Desarrollo', icon: '✏️', ext: 'https://codepen.io' },
    { id: 'replit', name: 'Replit IDE', cat: 'Desarrollo', icon: '⚡', ext: 'https://replit.com' },
    { id: 'stackblitz', name: 'StackBlitz', cat: 'Desarrollo', icon: '⚡', ext: 'https://stackblitz.com' },
    { id: 'hoppscotch', name: 'Hoppscotch API', cat: 'Desarrollo', icon: '🔌', ext: 'https://hoppscotch.io' },
    { id: 'jsoneditor', name: 'JSON Hero', cat: 'Desarrollo', icon: '{ }', ext: 'https://jsonhero.io' },
    { id: 'regex101', name: 'Regex Tester', cat: 'Desarrollo', icon: '🔍', ext: 'https://regex101.com' },
    { id: 'devdocs', name: 'DevDocs Manuales', cat: 'Desarrollo', icon: '📚', ext: 'https://devdocs.io' },
    { id: 'glitch', name: 'Glitch Web Dev', cat: 'Desarrollo', icon: '🎏', ext: 'https://glitch.com' },
    { id: 'jsfiddle', name: 'JSFiddle Sandbox', cat: 'Desarrollo', icon: '🎻', ext: 'https://jsfiddle.net' },

    // Creatividad & Diseño
    { id: 'figma', name: 'Figma Cloud', cat: 'Creatividad', icon: '🎨', ext: 'https://www.figma.com' },
    { id: 'canva', name: 'Canva Design', cat: 'Creatividad', icon: '✿', ext: 'https://www.canva.com' },
    { id: 'photopea', name: 'Photopea Photoshop', cat: 'Creatividad', icon: '🖌️', ext: 'https://www.photopea.com' },
    { id: 'excalidraw', name: 'Excalidraw', cat: 'Creatividad', icon: '✏️', ext: 'https://excalidraw.com' },
    { id: 'coolors', name: 'Coolors Paletas', cat: 'Creatividad', icon: '🌈', ext: 'https://coolors.co' },
    { id: 'piskel', name: 'Piskel Pixel Art', cat: 'Creatividad', icon: '👾', ext: 'https://www.piskelapp.com' },
    { id: 'threejs', name: 'Three.js 3D Editor', cat: 'Creatividad', icon: '🧊', ext: 'https://threejs.org/editor' },
    { id: 'svgedit', name: 'SVG-Edit Web', cat: 'Creatividad', icon: '✒️', ext: 'https://svg-edit.github.io/svgedit/' },

    // Multimedia & Audio
    { id: 'music', name: 'Reproductor EISEN', cat: 'Multimedia', icon: '🎵', desc: 'Audio persistente con sintetizador.' },
    { id: 'spotify', name: 'Spotify Player', cat: 'Multimedia', icon: '🟢', ext: 'https://open.spotify.com' },
    { id: 'youtube', name: 'YouTube Video', cat: 'Multimedia', icon: '▶️', ext: 'https://www.youtube.com' },
    { id: 'twitch', name: 'Twitch Streams', cat: 'Multimedia', icon: '🟣', ext: 'https://www.twitch.tv' },
    { id: 'soundcloud', name: 'SoundCloud Music', cat: 'Multimedia', icon: '☁️', ext: 'https://soundcloud.com' },
    { id: 'bandlab', name: 'BandLab DAW', cat: 'Multimedia', icon: '🎹', ext: 'https://www.bandlab.com' },
    { id: 'audiomass', name: 'AudioMass Waveform', cat: 'Multimedia', icon: '🎛️', ext: 'https://audiomass.co' },

    // Videojuegos
    { id: 'arcade', name: 'Centro Arcade Pro', cat: 'Juegos', icon: '🎮', desc: 'Ajedrez, Space Shooter y Snake.' },
    { id: 'chesscom', name: 'Chess.com', cat: 'Juegos', icon: '♟️', ext: 'https://www.chess.com' },
    { id: 'lichess', name: 'Lichess Free', cat: 'Juegos', icon: '♘', ext: 'https://lichess.org' },
    { id: 'krunker', name: 'Krunker FPS', cat: 'Juegos', icon: '🎯', ext: 'https://krunker.io' },
    { id: 'geoguessr', name: 'GeoGuessr Map', cat: 'Juegos', icon: '🌍', ext: 'https://www.geoguessr.com' }
  ];

  const tinyDescriptions = {
    notion:'Crea páginas, notas y bases de datos.', trello:'Organiza proyectos con tableros y tarjetas.', slack:'Comunícate con equipos y canales.', asana:'Planifica proyectos y tareas compartidas.', todoist:'Crea listas de tareas y recordatorios.', evernote:'Guarda notas y recortes web.', obsidian:'Conecta notas mediante enlaces.', miro:'Colabora en pizarras digitales.', airtable:'Organiza información en bases de datos.', coda:'Combina documentos con tablas y flujos.',
    vscode:'Edita código desde el navegador.', github:'Aloja repositorios y colabora en código.', codepen:'Prueba HTML, CSS y JavaScript.', replit:'Programa y ejecuta proyectos online.', stackblitz:'Desarrolla aplicaciones web en el navegador.', hoppscotch:'Prueba solicitudes a APIs.', jsoneditor:'Visualiza y edita datos JSON.', regex101:'Crea y prueba expresiones regulares.', devdocs:'Consulta documentación técnica.', glitch:'Crea y comparte proyectos web.', jsfiddle:'Experimenta con código web.',
    figma:'Diseña interfaces y prototipos.', canva:'Diseña presentaciones, carteles e imágenes.', photopea:'Edita imágenes por capas.', excalidraw:'Dibuja diagramas a mano alzada.', coolors:'Genera paletas de colores.', piskel:'Crea sprites y animaciones pixel art.', threejs:'Explora y edita escenas 3D.', svgedit:'Crea y modifica gráficos SVG.',
    spotify:'Escucha música en streaming.', youtube:'Busca y reproduce videos.', twitch:'Mira transmisiones en directo.', soundcloud:'Descubre y comparte audio.', bandlab:'Graba y mezcla música online.', audiomass:'Edita audio y formas de onda.', chesscom:'Juega ajedrez y resuelve problemas.', lichess:'Juega ajedrez gratis online.', krunker:'Accede a un juego de disparos web.', geoguessr:'Adivina lugares usando imágenes de mapas.'
  };
  const categoryDescriptions = {Productividad:'Organiza tareas, notas y documentos.',Desarrollo:'Crea, prueba o consulta código.',Creatividad:'Diseña gráficos, dibujos y prototipos.',Multimedia:'Reproduce o edita contenido multimedia.',Juegos:'Abre un juego o servicio de entretenimiento.',Ciencia:'Explora conceptos científicos.',Sistema:'Utilidad auxiliar para el entorno web.'};
  catalogList.forEach(app => { if (!app.desc) app.desc = tinyDescriptions[app.id] || categoryDescriptions[app.cat] || 'Acceso rápido a una herramienta web.'; });

  // Generación sistemática de apps para superar los 200 títulos completos
  const categoriesPool = ['Productividad', 'Desarrollo', 'Creatividad', 'Multimedia', 'Ciencia', 'Sistema', 'Juegos'];
  const prefixes = ['Smart', 'EISEN', 'Pro', 'Cloud', 'Hyper', 'Quick', 'Open', 'Data', 'Micro', 'Ultra', 'Core', 'Next', 'Prime', 'Web', 'Lab'];
  const nouns = [
    'Calc', 'Sync', 'Metrics', 'Flow', 'Diagram', 'Notes', 'Task', 'Compiler', 'Profiler', 'Inspector',
    'Vectorizer', 'Synthesizer', 'Sampler', 'Renderer', 'Physics', 'ChemLab', 'Algebra', 'Geometry',
    'SpeedTest', 'Cleaner', 'Benchmark', 'Monitor', 'HexView', 'Crypt', 'Compressor', 'Packer', 'Vault'
  ];

  let appCounter = catalogList.length;
  for (const pre of prefixes) {
    for (const noun of nouns) {
      if (catalogList.length >= 215) break;
      const cat = categoriesPool[(appCounter++) % categoriesPool.length];
      catalogList.push({
        id: 'auto-app-' + appCounter,
        name: `${pre} ${noun}`,
        cat: cat,
        icon: ['🧩', '🔬', '⚙️', '📐', '📦', '💡', '🏷️', '🛡️', '🛰️'][appCounter % 9],
        desc: `${({Calc:'Calcula operaciones básicas.',Sync:'Coordina datos entre servicios.',Metrics:'Consulta métricas y estadísticas.',Flow:'Organiza procesos y flujos.',Diagram:'Crea diagramas y esquemas.',Notes:'Guarda notas rápidas.',Task:'Organiza tareas pendientes.',Compiler:'Consulta herramientas de compilación.',Profiler:'Analiza rendimiento de código.',Inspector:'Revisa elementos y datos.',Vectorizer:'Convierte gráficos a vectores.',Synthesizer:'Explora síntesis de audio.',Sampler:'Prueba muestras de sonido.',Renderer:'Explora renderizado visual.',Physics:'Consulta recursos de física.',ChemLab:'Explora química educativa.',Algebra:'Practica conceptos algebraicos.',Geometry:'Consulta herramientas de geometría.',SpeedTest:'Busca pruebas de velocidad.',Cleaner:'Busca utilidades de limpieza.',Benchmark:'Consulta pruebas de rendimiento.',Monitor:'Consulta herramientas de monitoreo.',HexView:'Inspecciona datos hexadecimales.',Crypt:'Consulta herramientas criptográficas.',Compressor:'Busca compresión de archivos.',Packer:'Busca empaquetado de archivos.',Vault:'Consulta opciones de almacenamiento seguro.'})[noun] || `Atajo de búsqueda para ${cat.toLowerCase()}.`} Es un enlace de búsqueda, no una app instalada.` ,
        ext: 'https://www.google.com/search?igu=1&q=' + encodeURIComponent(`${pre} ${noun}`)
      });
    }
  }

  function renderAppCatalog(filterText = '', filterCat = 'all') {
    const container = $('#appstore-cards-container');
    const filtered = catalogList.filter(app => {
      const matchText = (app.name + ' ' + (app.desc || '')).toLowerCase().includes(filterText.toLowerCase());
      const matchCat = filterCat === 'all' || app.cat === filterCat;
      return matchText && matchCat;
    });

    container.innerHTML = filtered.map(app => `
      <div class="catalog-card-pro">
        <div class="cat-icon-badge">${app.icon}</div>
        <div style="flex:1;min-width:0;">
          <h4 style="font-size:13px;margin-bottom:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${app.name}</h4>
          <span style="font-size:10px;color:var(--accent);font-weight:600;">${app.cat}</span>
          <p class="app-mini-desc" title="${app.desc}">${app.desc}</p>
          <button class="btn-primary" style="padding:4px 10px;font-size:11px;" ${app.ext ? `data-external-url="${app.ext}"` : `data-launch="${app.id}"`}>
            ${app.ext ? (app.id.startsWith('auto-app-') ? 'Buscar en web ↗' : 'Abrir Web ↗') : 'Ejecutar'}
          </button>
        </div>
      </div>
    `).join('');
  }

  $('#appstore-search').oninput = e => renderAppCatalog(e.target.value);
  $$('#appstore-categories button').forEach(b => {
    b.onclick = () => {
      $$('#appstore-categories button').forEach(x => { x.className = 'btn-secondary'; });
      b.className = 'btn-primary';
      renderAppCatalog($('#appstore-search').value, b.dataset.cat);
    };
  });

  // Rellenar menú Inicio
  function renderStartMenu() {
    const pinnedContainer = $('#start-pinned-grid');
    pinnedContainer.innerHTML = catalogList.slice(0, 18).map(app => `
      <button class="start-app-item" title="${app.desc}" ${app.ext ? `data-external-url="${app.ext}"` : `data-launch="${app.id}"`}>
        <span class="start-ico">${app.icon}</span>
        <span class="start-name">${app.name}</span><span class="start-mini-desc">${app.desc}</span>
      </button>
    `).join('');

    $('#start-recents-list').innerHTML = `
      <div class="file-row-item" data-launch="word"><span>📄</span><span>Informe_Final.docx</span></div>
      <div class="file-row-item" data-launch="excel"><span>📊</span><span>Presupuesto_Mensual.xlsx</span></div>
      <div class="file-row-item" data-launch="arcade"><span>🚀</span><span>Space Shooter (Highscore: 1,420)</span></div>
    `;
  }

  /* --------------------------------------------------------------------------
     E. SUITE OFIMÁTICA (WORD, EXCEL, PDF)
     -------------------------------------------------------------------------- */
  // Word
  $$('[data-fmt]').forEach(btn => {
    btn.onclick = () => {
      document.execCommand(btn.dataset.fmt, false, null);
      $('#word-doc-body').focus();
    };
  });
  $('#word-btn-table').onclick = () => {
    const rows = prompt('Número de filas:', '3');
    const cols = prompt('Número de columnas:', '3');
    if (!rows || !cols) return;
    let html = '<table border="1" style="width:100%;border-collapse:collapse;margin:10px 0;">';
    for (let i = 0; i < rows; i++) {
      html += '<tr>';
      for (let j = 0; j < cols; j++) html += '<td style="padding:8px;border:1px solid #ccc;">&nbsp;</td>';
      html += '</tr>';
    }
    html += '</table><p></p>';
    document.execCommand('insertHTML', false, html);
  };
  $('#word-btn-save').onclick = () => {
    storage.set('word_doc', $('#word-doc-body').innerHTML);
    alert('Documento guardado localmente en EISENKU OS.');
  };
  $('#word-btn-pdf').onclick = () => {
    const printFrame = document.createElement('iframe');
    printFrame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
    printFrame.setAttribute('title', 'Vista de impresión del documento');
    document.body.appendChild(printFrame);
    const doc = printFrame.contentDocument;
    doc.open();
    doc.write(`<!doctype html><html><head><meta charset="utf-8"><title>Documento EISEN</title><style>body{font-family:Arial,sans-serif;padding:40px;color:#111}table{border-collapse:collapse}td,th{border:1px solid #999;padding:6px}</style></head><body>${$('#word-doc-body').innerHTML}</body></html>`);
    doc.close();
    printFrame.onload = () => { printFrame.contentWindow.focus(); printFrame.contentWindow.print(); setTimeout(() => printFrame.remove(), 1000); };
  };

  // Excel
  const excelState = { rows: 18, cols: 8, data: storage.get('excel_data', {}) };
  function renderExcelTable() {
    const thRow = $('#excel-th-row');
    const tableBody = $('#excel-main-table tbody');
    thRow.innerHTML = '<th></th>';
    for (let c = 0; c < excelState.cols; c++) {
      thRow.innerHTML += `<th>${String.fromCharCode(65 + c)}</th>`;
    }
    tableBody.innerHTML = '';
    for (let r = 1; r <= excelState.rows; r++) {
      let tr = `<tr><th>${r}</th>`;
      for (let c = 0; c < excelState.cols; c++) {
        const cellId = String.fromCharCode(65 + c) + r;
        const val = excelState.data[cellId] || '';
        tr += `<td><input class="excel-cell-input" data-cell="${cellId}" value="${val}"></td>`;
      }
      tr += '</tr>';
      tableBody.innerHTML += tr;
    }
    bindExcelEvents();
    refreshExcelComputedValues();
  }

  function evaluateFormula(expr, stack = new Set()) {
    if (expr == null || expr === '') return '';
    const raw = String(expr).trim(); if (!raw.startsWith('=')) return raw;
    try {
      let clean = raw.slice(1).toUpperCase();
      const cellValue = cell => {
        if (stack.has(cell)) throw new Error('Referencia circular');
        const v = excelState.data[cell] ?? '';
        if (String(v).startsWith('=')) { const next=new Set(stack); next.add(cell); return Number(evaluateFormula(v,next)) || 0; }
        return Number(v) || 0;
      };
      clean=clean.replace(/(SUM|AVERAGE|AVG|MIN|MAX|COUNT)\(([A-Z]+\d+):([A-Z]+\d+)\)/g,(_,fn,first,last)=>{
        const a=first.match(/^([A-Z]+)(\d+)$/),b=last.match(/^([A-Z]+)(\d+)$/); if(!a||!b||a[1]!==b[1]) throw new Error('Rango no compatible');
        const lo=Math.min(+a[2],+b[2]),hi=Math.max(+a[2],+b[2]),vals=[];for(let r=lo;r<=hi;r++)vals.push(cellValue(a[1]+r));
        if(fn==='SUM')return String(vals.reduce((x,y)=>x+y,0)); if(fn==='AVERAGE'||fn==='AVG')return String(vals.length?vals.reduce((x,y)=>x+y,0)/vals.length:0);
        if(fn==='MIN')return String(Math.min(...vals));if(fn==='MAX')return String(Math.max(...vals));return String(vals.filter(v=>v!==0).length);
      });
      clean=clean.replace(/\b([A-Z]+\d+)\b/g,(_,cell)=>String(cellValue(cell)));
      const tokens=clean.match(/(?:\d+(?:\.\d*)?|\.\d+)|[()+*/-]/g)||[];
      if(tokens.join('')!==clean.replace(/\s+/g,''))throw new Error('Fórmula inválida');
      let i=0;
      function primary(){const t=tokens[i++];if(t==='+')return primary();if(t==='-')return-primary();if(t==='('){const v=expression();if(tokens[i++]!==')')throw new Error('Falta )');return v;}if(t==null||!Number.isFinite(Number(t)))throw new Error('Número inválido');return Number(t);}
      function term(){let v=primary();while(tokens[i]==='*'||tokens[i]==='/'){const op=tokens[i++],n=primary();v=op==='*'?v*n:v/n;}return v;}
      function expression(){let v=term();while(tokens[i]==='+'||tokens[i]==='-'){const op=tokens[i++],n=term();v=op==='+'?v+n:v-n;}return v;}
      const result=expression();if(i!==tokens.length||!Number.isFinite(result))return '#ERROR!';return Number(result.toFixed(8));
    } catch { return '#ERROR!'; }
  }
  let excelFocusedCell='A1';
  function bindExcelEvents(){
    $$('.excel-cell-input').forEach(inp=>{
      inp.onfocus=()=>{excelFocusedCell=inp.dataset.cell;$('#excel-active-cell').textContent=excelFocusedCell;$('#excel-formula-input').value=excelState.data[excelFocusedCell]??'';};
      inp.onchange=()=>{excelState.data[inp.dataset.cell]=inp.value;storage.set('excel_data',excelState.data);refreshExcelComputedValues();};
      inp.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();inp.blur();}};
    });
  }
  function refreshExcelComputedValues(){
    $$('.excel-cell-input').forEach(inp=>{const raw=excelState.data[inp.dataset.cell]??'';if(document.activeElement!==inp)inp.value=String(raw).startsWith('=')?evaluateFormula(raw):raw;inp.title=String(raw).startsWith('=')?raw:'';});
  }
  function commitExcelFormula(){if(!excelFocusedCell)return;excelState.data[excelFocusedCell]=$('#excel-formula-input').value;storage.set('excel_data',excelState.data);renderExcelTable();const target=$(`[data-cell="${excelFocusedCell}"]`);if(target)target.focus();refreshExcelComputedValues();}
  $('#excel-formula-input').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();commitExcelFormula();}});
  $('#excel-formula-input').addEventListener('change',commitExcelFormula);

  $('#sheet-btn-addrow').onclick = () => { excelState.rows += 5; renderExcelTable(); };
  $('#sheet-btn-csv').onclick = () => {
    let csv = '';
    for (let r = 1; r <= excelState.rows; r++) {
      let row = [];
      for (let c = 0; c < excelState.cols; c++) {
        row.push(`"${excelState.data[String.fromCharCode(65 + c) + r] || ''}"`);
      }
      csv += row.join(',') + '\r\n';
    }
    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'Hoja_EISEN.csv'; a.click();
  };

  $('#sheet-btn-sum').onclick=()=>{
    const nums=Object.values(excelState.data).map(v=>String(v).startsWith('=')?Number(evaluateFormula(v)):Number(v)).filter(Number.isFinite);
    const cell=excelFocusedCell||'A1';excelState.data[cell]=String(nums.reduce((a,b)=>a+b,0));storage.set('excel_data',excelState.data);renderExcelTable();const t=$(`[data-cell="${cell}"]`);if(t)t.focus();
  };
  $('#sheet-btn-sort').onclick=()=>{const vals=[];for(let r=1;r<=excelState.rows;r++)vals.push(excelState.data['A'+r]??'');vals.sort((a,b)=>String(a).localeCompare(String(b),undefined,{numeric:true,sensitivity:'base'}));vals.forEach((v,i)=>excelState.data['A'+(i+1)]=v);storage.set('excel_data',excelState.data);renderExcelTable();};
  $('#sheet-btn-chart').onclick=()=>{
    const vals=[];
    for(let r=1;r<=excelState.rows;r++){
      const raw=excelState.data['A'+r]??'';
      const n=Number(String(raw).startsWith('=')?evaluateFormula(raw):raw);
      if(raw!==''&&Number.isFinite(n)) vals.push({label:'A'+r,value:n});
    }
    if(!vals.length){alert('Escribe números en la columna A para crear un gráfico.');return;}
    const max=Math.max(...vals.map(x=>Math.abs(x.value)),1);
    const bars=vals.map(x=>`<div style="display:flex;align-items:center;gap:10px;margin:10px 0"><b style="width:36px">${x.label}</b><div style="height:22px;width:${Math.max(2,Math.min(100,Math.abs(x.value)/max*100))}%;background:#0078d4;border-radius:4px"></div><span>${x.value}</span></div>`).join('');
    const html=`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><body style="font:14px system-ui;padding:24px;background:#fff;color:#111"><h2>Gráfico · Columna A</h2>${bars}</body>`;
    ebOpenHtml('Gráfico de EISEN Sheets',html);
  }

  // PDF
  $('#pdf-print-current').onclick=()=>{const f=$('#pdf-viewer-frame');if($('#pdf-empty-placeholder').style.display!=='none'){alert('Primero carga un PDF.');return;}try{f.contentWindow.focus();f.contentWindow.print();}catch{alert('El navegador no permite imprimir este PDF desde el visor integrado. Usa los controles del visor para guardarlo o imprimirlo.');}};
  $('#pdf-file-picker').onchange = e => {
    const file = e.target.files[0];
    if (file) {
      const url = URL.createObjectURL(file);
      $('#pdf-viewer-frame').src = url;
      $('#pdf-empty-placeholder').style.display = 'none';
    }
  };

  /* --------------------------------------------------------------------------
     F. VIDEOJUEGOS: SPACE SHOOTER 2D & AJEDREZ JUGABLE
     -------------------------------------------------------------------------- */
  // Pestañas de juegos
  $('#arcade-tab-shooter').onclick = () => {
    $('#arcade-mod-shooter').style.display = 'flex';
    $('#arcade-mod-chess').style.display = 'none';
    $('#arcade-mod-snake').style.display = 'none';
    initShooterGame();
  };
  $('#arcade-tab-chess').onclick = () => {
    $('#arcade-mod-shooter').style.display = 'none';
    $('#arcade-mod-chess').style.display = 'flex';
    $('#arcade-mod-snake').style.display = 'none';
    initChessGame();
  };
  $('#arcade-tab-snake').onclick = () => {
    $('#arcade-mod-shooter').style.display = 'none';
    $('#arcade-mod-chess').style.display = 'none';
    $('#arcade-mod-snake').style.display = 'flex';
    initSnakeGame();
  };

  // 1. Shooter 2D
  let shooterLoop = null;
  function initShooterGame() {
    const canvas = $('#shooter-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let ship = { x: canvas.width / 2 - 15, y: canvas.height - 40, w: 30, h: 20, speed: 6 };
    let bullets = [], enemies = [], score = 0, lives = 3;
    let keys = {};

    window.onkeydown = e => keys[e.code] = true;
    window.onkeyup = e => keys[e.code] = false;

    // Disparo y movimiento táctil
    canvas.onpointerdown = e => {
      const rect = canvas.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      if (clickX < canvas.width / 3) ship.x -= 20;
      else if (clickX > (canvas.width * 2) / 3) ship.x += 20;
      bullets.push({ x: ship.x + ship.w / 2 - 2, y: ship.y, w: 4, h: 10, speed: 8 });
    };

    $('#shooter-btn-start').onclick = () => {
      score = 0; lives = 3; bullets = []; enemies = [];
      $('#shooter-score').textContent = '0';
      $('#shooter-lives').textContent = '3';
      clearInterval(shooterLoop);
      shooterLoop = setInterval(update, 1000 / 60);
    };

    function update() {
      if (keys['ArrowLeft'] || keys['KeyA']) ship.x = Math.max(0, ship.x - ship.speed);
      if (keys['ArrowRight'] || keys['KeyD']) ship.x = Math.min(canvas.width - ship.w, ship.x + ship.speed);
      if (keys['Space']) {
        if (!ship.cooldown) {
          bullets.push({ x: ship.x + ship.w / 2 - 2, y: ship.y, w: 4, h: 10, speed: 9 });
          ship.cooldown = 12;
        }
      }
      if (ship.cooldown) ship.cooldown--;

      // Generar enemigos
      if (Math.random() < 0.03) {
        enemies.push({ x: Math.random() * (canvas.width - 25), y: -20, w: 25, h: 20, speed: 2 + Math.random() * 2 });
      }

      // Dibujar
      ctx.fillStyle = '#080b11'; ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Jugador
      ctx.fillStyle = '#0078d4'; ctx.fillRect(ship.x, ship.y, ship.w, ship.h);

      // Balas
      ctx.fillStyle = '#ff5ebc';
      bullets.forEach((b, i) => {
        b.y -= b.speed;
        ctx.fillRect(b.x, b.y, b.w, b.h);
        if (b.y < -10) bullets.splice(i, 1);
      });

      // Enemigos
      ctx.fillStyle = '#e81123';
      enemies.forEach((en, i) => {
        en.y += en.speed;
        ctx.fillRect(en.x, en.y, en.w, en.h);

        // Colisión con balas
        bullets.forEach((b, bi) => {
          if (b.x < en.x + en.w && b.x + b.w > en.x && b.y < en.y + en.h && b.y + b.h > en.y) {
            enemies.splice(i, 1);
            bullets.splice(bi, 1);
            score += 20;
            $('#shooter-score').textContent = score;
          }
        });

        // Colisión con nave
        if (en.y > canvas.height) {
          enemies.splice(i, 1);
          lives--;
          $('#shooter-lives').textContent = lives;
          if (lives <= 0) {
            clearInterval(shooterLoop);
            alert('¡Fin de la partida! Puntuación final: ' + score);
          }
        }
      });
    }
  }

  // 2. Ajedrez con reglas legales: jaque, enroque, captura al paso, promoción y mate.
  function initChessGame() {
    const boardEl = $('#chess-board-dom');
    if (boardEl.dataset.ready === '1') return;
    boardEl.dataset.ready = '1';
    const glyph = {K:'♔',Q:'♕',R:'♖',B:'♗',N:'♘',P:'♙',k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟'};
    const dirs = {n:[-33,-31,-18,-14,14,18,31,33],b:[-17,-15,15,17],r:[-16,-1,1,16],q:[-17,-16,-15,-1,1,15,16,17],k:[-17,-16,-15,-1,1,15,16,17]};
    const on = i => i >= 0 && i < 128 && !(i & 0x88);
    const side = p => !p || p==='.' ? 0 : p===p.toUpperCase() ? 1 : -1;
    const sqName = i => 'abcdefgh'[i&7] + (8-(i>>4));
    const fromName = x => (8-Number(x[1]))*16+'abcdefgh'.indexOf(x[0]);
    let state, selected=-1, legalMoves=[], history=[];
    function initial(){return {b:Array.from({length:128},(_,i)=>{if(!on(i))return ' ';const row=i>>4,col=i&7;const back='rnbqkbnr';return row===0?back[col]:row===1?'p':row===6?'P':row===7?back[col].toUpperCase():'.';}),t:1,c:15,ep:-1,half:0,full:1};}
    function attacked(s,target,by){
      for(let f=0;f<128;f++){
        if(!on(f)||side(s.b[f])!==by)continue;
        const p=s.b[f].toLowerCase();
        if(p==='p'){if(target===f-16*by-1||target===f-16*by+1)return true;continue;}
        for(const d of (dirs[p]||[]))for(let t=f+d;on(t);t+=d){if(t===target)return true;if(s.b[t]!=='.'||p==='n'||p==='k')break;}
      }
      return false;
    }
    function inCheck(s,color=s.t){const k=s.b.indexOf(color===1?'K':'k');return k<0||attacked(s,k,-color);}
    function apply(s,m){
      const [f,t,promo,flag]=m,b=s.b.slice(),piece=b[f],captured=flag==='ep'?b[t+16*s.t]:b[t];let c=s.c;
      b[f]='.';b[t]=promo?(s.t===1?promo.toUpperCase():promo):piece;
      if(flag==='ep')b[t+16*s.t]='.';
      if(flag==='castle'){const rf=t>f?f+3:f-4,rt=t>f?f+1:f-1;b[rt]=b[rf];b[rf]='.';}
      if(piece==='K')c&=~3;if(piece==='k')c&=~12;
      const rb={119:1,112:2,7:4,0:8};if(piece.toLowerCase()==='r')c&=~(rb[f]||0);if(captured.toLowerCase()==='r')c&=~(rb[t]||0);
      return {b,t:-s.t,c,ep:piece.toLowerCase()==='p'&&Math.abs(t-f)===32?(t+f)/2:-1,half:piece.toLowerCase()==='p'||captured!=='.'?0:s.half+1,full:s.full+(s.t===-1?1:0)};
    }
    function pseudo(s){
      const out=[];
      for(let f=0;f<128;f++){
        if(!on(f)||side(s.b[f])!==s.t)continue;const p=s.b[f].toLowerCase();
        const add=(t,flag='')=>{if(!on(t)||s.b[t].toLowerCase()==='k')return;if(p==='p'&&((t>>4)===0||(t>>4)===7)){for(const q of ['q','r','b','n'])out.push([f,t,q,flag]);}else out.push([f,t,'',flag]);};
        if(p==='p'){
          const t=f-16*s.t;if(on(t)&&s.b[t]==='.'){add(t);const u=t-16*s.t;if((f>>4)===(s.t===1?6:1)&&s.b[u]==='.')add(u);}
          for(const d of [-1,1]){const u=t+d;if(!on(u))continue;if(side(s.b[u])===-s.t)add(u);else if(u===s.ep&&s.b[u]==='.'&&s.b[u+16*s.t]===(s.t===1?'p':'P'))add(u,'ep');}
        }else{
          for(const d of (dirs[p]||[]))for(let t=f+d;on(t);t+=d){if(side(s.b[t])===s.t)break;add(t);if(s.b[t]!=='.'||p==='n'||p==='k')break;}
          const home=s.t===1?116:4,rook=s.t===1?'R':'r',bits=s.t===1?[1,2]:[4,8];
          if(p==='k'&&f===home&&!inCheck(s)){
            if((s.c&bits[0])&&s.b[f+3]===rook&&s.b[f+1]==='.'&&s.b[f+2]==='.'&&!attacked(s,f+1,-s.t)&&!attacked(s,f+2,-s.t))add(f+2,'castle');
            if((s.c&bits[1])&&s.b[f-4]===rook&&s.b[f-1]==='.'&&s.b[f-2]==='.'&&s.b[f-3]==='.'&&!attacked(s,f-1,-s.t)&&!attacked(s,f-2,-s.t))add(f-2,'castle');
          }
        }
      }
      return out;
    }
    function legal(s){return pseudo(s).filter(m=>!inCheck(apply(s,m),s.t));}
    function status(){const ms=legal(state),check=inCheck(state);if(!ms.length)return check?`Jaque mate. Ganan ${state.t===1?'Negras':'Blancas'}.`:'Tablas por ahogado.';return `Turno: ${state.t===1?'Blancas':'Negras'}${check?' · ¡Jaque!':''}`;}
    function render(){
      boardEl.innerHTML='';legalMoves=legal(state);const targets=selected<0?[]:legalMoves.filter(m=>m[0]===selected).map(m=>m[1]);
      for(let r=0;r<8;r++)for(let c=0;c<8;c++){
        const i=r*16+c,el=document.createElement('div');el.className=`chess-square ${(r+c)%2===0?'light':'dark'}`;el.dataset.i=i;el.textContent=state.b[i]==='.'?'':glyph[state.b[i]];
        if(i===selected)el.classList.add('selected');if(targets.includes(i))el.classList.add('target');
        el.onclick=()=>clickSquare(i);boardEl.appendChild(el);
      }
      $('#chess-status').textContent=status();
    }
    function doMove(m){state=apply(state,m);history.push(state);selected=-1;render();if($('#chess-mode').value==='ai'&&state.t===-1&&legal(state).length){setTimeout(aiMove,250);}}
    function clickSquare(i){if(!legal(state).length)return;const piece=state.b[i];if(selected>=0){let choices=legalMoves.filter(m=>m[0]===selected&&m[1]===i);if(choices.length){if(choices.length>1){const answer=(prompt('Promoción: escribe dama, torre, alfil o caballo','dama')||'dama').toLowerCase();const map={dama:'q',reina:'q',q:'q',torre:'r',r:'r',alfil:'b',b:'b',caballo:'n',n:'n',knight:'n'};const promo=map[answer]||'q';doMove(choices.find(m=>m[2]===promo)||choices[0]);}else doMove(choices[0]);return;}}
      if(side(piece)===state.t&&!(($('#chess-mode').value==='ai')&&state.t===-1)){selected=i;render();}else{selected=-1;render();}}
    function aiMove(){if($('#chess-mode').value!=='ai'||state.t!==-1)return;const ms=legal(state);if(!ms.length){render();return;}const captures=ms.filter(m=>state.b[m[1]]!=='.'||m[3]==='ep');const pool=captures.length&&Math.random()<0.65?captures:ms;doMove(pool[Math.floor(Math.random()*pool.length)]);}
    $('#chess-restart').onclick=()=>{state=initial();selected=-1;history=[state];render();};
    $('#chess-mode').onchange=()=>{state=initial();selected=-1;history=[state];render();};
    state=initial();history=[state];render();
  }

  // 3. Snake Retro
  function initSnakeGame() {
    const canvas = $('#snake-canvas');
    const ctx = canvas.getContext('2d');
    let snake = [{x: 10, y: 10}], food = {x: 5, y: 5}, dx = 1, dy = 0, score = 0, snakeTimer = null;
    if(canvas.dataset.touchReady!=='1'){canvas.dataset.touchReady='1';canvas.addEventListener('pointerdown',e=>{const r=canvas.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;if(x<0.25){dx=-1;dy=0;}else if(x>0.75){dx=1;dy=0;}else if(y<0.5){dx=0;dy=-1;}else{dx=0;dy=1;}});}

    $('#snake-restart').onclick = () => {
      snake = [{x: 10, y: 10}]; dx = 1; dy = 0; score = 0;
      clearInterval(snakeTimer);
      snakeTimer = setInterval(step, 100);
    };

    if (canvas._snakeKeyHandler) window.removeEventListener('keydown', canvas._snakeKeyHandler);
    canvas._snakeKeyHandler = e => {
      if (!$('#win-arcade').classList.contains('open') || $('#arcade-mod-snake').style.display === 'none') return;
      if (e.key === 'ArrowUp' && dy === 0) { dx = 0; dy = -1; }
      if (e.key === 'ArrowDown' && dy === 0) { dx = 0; dy = 1; }
      if (e.key === 'ArrowLeft' && dx === 0) { dx = -1; dy = 0; }
      if (e.key === 'ArrowRight' && dx === 0) { dx = 1; dy = 0; }
    };
    window.addEventListener('keydown', canvas._snakeKeyHandler);

    function step() {
      const head = {x: snake[0].x + dx, y: snake[0].y + dy};
      snake.unshift(head);
      if (head.x === food.x && head.y === food.y) {
        score += 10;
        $('#snake-score').textContent = score;
        food = {x: Math.floor(Math.random() * 20), y: Math.floor(Math.random() * 20)};
      } else {
        snake.pop();
      }

      // Colisiones bordes
      if (head.x < 0 || head.x >= 20 || head.y < 0 || head.y >= 20 || snake.slice(1).some(p => p.x === head.x && p.y === head.y)) {
        clearInterval(snakeTimer);
        alert('Juego terminado. Puntos: ' + score);
        return;
      }

      ctx.fillStyle = '#111'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#0078d4';
      snake.forEach(part => ctx.fillRect(part.x * 20, part.y * 20, 18, 18));
      ctx.fillStyle = '#8df0b0'; ctx.fillRect(food.x * 20, food.y * 20, 18, 18);
    }
  }

  /* --------------------------------------------------------------------------
     G. REPRODUCTOR DE MÚSICA PERSISTENTE (WEB AUDIO SYNTH)
     -------------------------------------------------------------------------- */
  const AudioContextClass=window.AudioContext||window.webkitAudioContext;
  let audioCtx=null,synthOsc=null,synthGain=null,isPlaying=false,audioPlaylist=[],playlistIndex=0,activeAudio=null;
  function getAudioContext(){if(!AudioContextClass)return null;if(!audioCtx)audioCtx=new AudioContextClass();return audioCtx;}
  function updateAudioUI(playing){isPlaying=playing;$('#p-play-main').textContent=playing?'⏸':'▶';$('#qc-play').textContent=playing?'⏸':'▶';}
  function stopSynth(){if(synthOsc){try{synthOsc.stop();}catch{}synthOsc=null;}synthGain=null;}
  function stopTrack(){if(activeAudio){activeAudio.pause();activeAudio.currentTime=0;activeAudio=null;}stopSynth();updateAudioUI(false);}
  function playSynthTrack(){const ctx=getAudioContext();if(!ctx){alert('Este navegador no admite audio web.');return;}ctx.resume();stopSynth();synthOsc=ctx.createOscillator();synthGain=ctx.createGain();synthOsc.type='sawtooth';synthOsc.frequency.setValueAtTime(220,ctx.currentTime);synthGain.gain.setValueAtTime(Number($('#player-vol-slider').value)*0.08,ctx.currentTime);synthOsc.connect(synthGain);synthGain.connect(ctx.destination);synthOsc.start();$('#player-track-name').textContent='EISEN Synthwave';$('#qc-track-title').textContent='EISEN Synthwave';updateAudioUI(true);}
  function playPlaylistIndex(index){if(!audioPlaylist.length){playSynthTrack();return;}stopTrack();playlistIndex=(index+audioPlaylist.length)%audioPlaylist.length;activeAudio=new Audio(audioPlaylist[playlistIndex].url);activeAudio.volume=Number($('#player-vol-slider').value);activeAudio.onended=()=>playPlaylistIndex(playlistIndex+1);activeAudio.onerror=()=>{updateAudioUI(false);alert('No se pudo reproducir este archivo de audio.');};$('#player-track-name').textContent=audioPlaylist[playlistIndex].name;$('#qc-track-title').textContent=audioPlaylist[playlistIndex].name;activeAudio.play().then(()=>updateAudioUI(true)).catch(()=>{updateAudioUI(false);alert('Toca Reproducir para permitir el audio en el navegador.');});}
  function togglePlayback(){if(activeAudio){if(activeAudio.paused)activeAudio.play().then(()=>updateAudioUI(true)).catch(()=>{});else{activeAudio.pause();updateAudioUI(false);}return;}if(isPlaying)stopTrack();else playSynthTrack();}
  $('#p-play-main').onclick=togglePlayback;$('#qc-play').onclick=togglePlayback;
  $('#p-next').onclick=$('#qc-next').onclick=()=>playPlaylistIndex(playlistIndex+1);$('#p-prev').onclick=$('#qc-prev').onclick=()=>playPlaylistIndex(playlistIndex-1);
  function syncVolume(value){const v=Math.max(0,Math.min(1,Number(value)));$('#player-vol-slider').value=v;$('#qc-volume').value=v;if(activeAudio)activeAudio.volume=v;if(synthGain&&audioCtx)synthGain.gain.setTargetAtTime(v*0.08,audioCtx.currentTime,0.02);storage.set('volume',v);}
  $('#player-vol-slider').oninput=e=>syncVolume(e.target.value);$('#qc-volume').oninput=e=>syncVolume(e.target.value);syncVolume(storage.get('volume',0.8));
  $('#audio-file-input').onchange=e=>{const files=[...e.target.files];if(!files.length)return;audioPlaylist.forEach(x=>URL.revokeObjectURL(x.url));audioPlaylist=files.map(file=>({name:file.name,url:URL.createObjectURL(file)}));playlistIndex=0;playPlaylistIndex(0);};

  /* --------------------------------------------------------------------------
     H. EXPLORADOR DE ARCHIVOS PRO
     -------------------------------------------------------------------------- */
  const virtualFS = storage.get('vfs', [
    { name: 'Manual_Usuario.txt', type: 'text', folder: 'documents', size: '2 KB' },
    { name: 'Foto_Fondo.png', type: 'img', folder: 'images', size: '180 KB' },
    { name: 'Pistas_Musica.mp3', type: 'audio', folder: 'music', size: '4.2 MB' }
  ]);
  let currentFolder = 'documents';

  function renderExplorer() {
    const container = $('#explorer-items-list');
    const items = virtualFS.filter(f => f.folder === currentFolder);
    container.innerHTML = items.map((f, i) => `
      <div class="file-row-item ui-between" ondblclick="alert('Abriendo: ${f.name}')">
        <div class="ui-row">
          <span>${f.type === 'text' ? '📄' : f.type === 'img' ? '🖼️' : '📁'}</span>
          <span style="font-size:12px;font-weight:500;">${f.name}</span>
        </div>
        <span style="font-size:11px;color:var(--text-muted);">${f.size}</span>
      </div>
    `).join('') || '<div style="padding:20px;text-align:center;color:var(--text-muted);">Carpeta vacía</div>';
  }

  $$('.explorer-sidebar button').forEach(b => {
    b.onclick = () => {
      currentFolder = b.dataset.folder;
      $('#explorer-current-path').textContent = `/Este Equipo/${b.textContent.trim()}`;
      renderExplorer();
    };
  });

  $('#fs-btn-new-file').onclick = () => {
    const n = prompt('Nombre del nuevo archivo:', 'nota.txt');
    if (!n) return;
    virtualFS.push({ name: n, type: 'text', folder: currentFolder, size: '1 KB' });
    storage.set('vfs', virtualFS);
    renderExplorer();
  };

  /* --------------------------------------------------------------------------
     I. TERMINAL EDUCATIVA
     -------------------------------------------------------------------------- */
  const termHistory = $('#term-log');
  const termInput = $('#term-input-cmd');

  termInput.onkeydown = e => {
    if (e.key === 'Enter') {
      const cmd = termInput.value.trim();
      termHistory.innerHTML += `eisen@desktop:~$ ${cmd}\n`;
      execTerm(cmd);
      termInput.value = '';
      termHistory.scrollTop = termHistory.scrollHeight;
    }
  };

  function execTerm(cmd) {
    const c = cmd.toLowerCase();
    if (c === 'help') {
      termHistory.innerHTML += `Comandos disponibles:\n  help      - Lista de comandos\n  dir / ls  - Listar archivos\n  clear     - Limpiar pantalla\n  neofetch  - Especificaciones del sistema\n  date      - Fecha y hora actual\n`;
    } else if (c === 'clear') {
      termHistory.innerHTML = '';
    } else if (c === 'ls' || c === 'dir') {
      termHistory.innerHTML += virtualFS.map(f => `  ${f.name} (${f.size})`).join('\n') + '\n';
    } else if (c === 'neofetch') {
      termHistory.innerHTML += `
  .---.      OS: EISENKU OS 7.0 Pro Web Edition
 /     \\     Kernel: HTML5 / ES6 Web Desktop
| () () |    Shell: EISEN Terminal Pro
 \\  _  /     Apps: 200+ Catalogadas
  \`---\`      Memoria: LocalStorage 5MB Virtual\n`;
    } else if (c === 'date') {
      termHistory.innerHTML += new Date().toString() + '\n';
    } else {
      termHistory.innerHTML += `Comando no reconocido: ${c}. Escribe 'help'.\n`;
    }
  }

  /* --------------------------------------------------------------------------
     J. RELOJ, AJUSTES & WALLPAPER
     -------------------------------------------------------------------------- */
  function updateClock() {
    const now = new Date();
    $('#clock-time').textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    $('#clock-date').textContent = now.toLocaleDateString([], { day: '2-digit', month: '2-digit', year: 'numeric' });
  }
  setInterval(updateClock, 1000);
  updateClock();

  // Fondos de pantalla
  const wallpapers = {
    flow: 'radial-gradient(ellipse at 80% 20%, #1e4287 0%, transparent 50%), radial-gradient(ellipse at 20% 80%, #0078d4 0%, transparent 45%), linear-gradient(135deg, #09101d, #0b1528)',
    'dark-flow': 'linear-gradient(135deg, #090b10 0%, #171b26 50%, #090b10 100%)',
    nature: 'linear-gradient(135deg, #0d324d 0%, #7f5a83 100%)',
    cyber: 'radial-gradient(circle, #ff007f 0%, #000000 80%)'
  };

  $('#cfg-wallpaper').onchange=e=>{$('#desktop-viewport').style.backgroundImage=wallpapers[e.target.value];storage.set('wp',e.target.value);storage.set('customWallpaper','');};
  const savedWallpaper=storage.get('wp','flow');
  if(savedWallpaper==='custom'&&storage.get('customWallpaper',''))$('#desktop-viewport').style.backgroundImage=`url("${storage.get('customWallpaper','')}")`;
  else{$('#cfg-wallpaper').value=wallpapers[savedWallpaper]?savedWallpaper:'flow';$('#desktop-viewport').style.backgroundImage=wallpapers[$('#cfg-wallpaper').value];}

  function applyTheme(theme){document.documentElement.dataset.theme=theme;$('#cfg-theme').value=theme;storage.set('theme',theme);}
  $('#cfg-theme').onchange=e=>applyTheme(e.target.value);applyTheme(storage.get('theme','dark'));
  $('#cfg-accent').value=storage.get('accent','#0078d4');
  function applyAccent(color){document.documentElement.style.setProperty('--accent',color);document.documentElement.style.setProperty('--accent-light',color);const n=parseInt(color.slice(1),16),r=(n>>16)&255,g=(n>>8)&255,b=n&255;document.documentElement.style.setProperty('--accent-glow',`rgba(${r},${g},${b},0.35)`);storage.set('accent',color);}
  applyAccent($('#cfg-accent').value);$('#cfg-accent').oninput=e=>applyAccent(e.target.value);
  $('#cfg-btn-custom-bg').onclick=()=>$('#cfg-file-bg').click();
  $('#cfg-file-bg').onchange=e=>{const file=e.target.files[0];if(!file)return;if(file.size>4*1024*1024){alert('Elige una imagen de hasta 4 MB para no llenar el almacenamiento local.');return;}const reader=new FileReader();reader.onload=()=>{const data=reader.result;$('#desktop-viewport').style.backgroundImage=`url("${data}")`;storage.set('customWallpaper',data);storage.set('wp','custom');};reader.readAsDataURL(file);};
  $('#cfg-btn-backup').onclick=()=>{const data={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith('eisen_'))data[k]=localStorage.getItem(k);}const blob=new Blob([JSON.stringify({app:'EISENKU OS',version:'7.1',created:new Date().toISOString(),data},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='EISENKU_OS_respaldo.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};
  $('#cfg-btn-restore').onclick=()=>$('#cfg-file-restore').click();
  $('#cfg-file-restore').onchange=e=>{const file=e.target.files[0];if(!file)return;const reader=new FileReader();reader.onload=()=>{try{const obj=JSON.parse(reader.result);if(!obj.data||typeof obj.data!=='object')throw new Error();Object.entries(obj.data).forEach(([k,v])=>{if(k.startsWith('eisen_'))localStorage.setItem(k,v);});alert('Respaldo restaurado. La página se recargará.');location.reload();}catch{alert('El archivo no parece ser un respaldo válido de EISENKU OS.');}};reader.readAsText(file);};
  $('#cfg-btn-reset').onclick=()=>{if(confirm('¿Restablecer EISENKU OS? Se borrarán los datos locales. Exporta un respaldo antes si quieres conservarlos.')){Object.keys(localStorage).filter(k=>k.startsWith('eisen_')).forEach(k=>localStorage.removeItem(k));location.reload();}};
  $('#sys-btn-restart').onclick=()=>{if(confirm('¿Reiniciar la interfaz de EISENKU OS?'))location.reload();};
  $('#qt-dark').onclick=()=>applyTheme(document.documentElement.dataset.theme==='light'?'dark':'light');
  ['qt-wifi','qt-bt'].forEach(id=>{const el=$('#'+id);el.onclick=()=>{el.classList.toggle('active');el.setAttribute('aria-pressed',el.classList.contains('active')?'true':'false');};});
  $('#start-search-input').oninput=e=>{const q=e.target.value.trim().toLowerCase();if(q){openWindow('appcenter');$('#appstore-search').value=q;renderAppCatalog(q);}};
  const storageInfo=$('#cfg-storage-info');if(storageInfo){let bytes=0;for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith('eisen_'))bytes+=(localStorage.getItem(k)||'').length*2;}storageInfo.textContent=`Uso local aproximado: ${(bytes/1024).toFixed(1)} KB. El navegador puede limitar este espacio.`;}

  /* --------------------------------------------------------------------------
     K. INICIALIZACIÓN GENERAL
     -------------------------------------------------------------------------- */
  setupWindowInteractions();
  renderAppCatalog();
  renderStartMenu();
  updateTaskbarButtons();

})();
